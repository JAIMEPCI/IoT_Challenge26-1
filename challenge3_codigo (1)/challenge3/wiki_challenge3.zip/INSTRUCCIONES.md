# Cómo subir la wiki del Challenge 3 (unos 20 minutos)

## 1. Agrega la gráfica que solo está en tu PC

Copia `challenge3\gateway\resultados\serie_tiempo.png` (de tu PC) dentro de
`subir_al_repositorio\challenge3\imagenes\`.

Opcional: copia también tu carpeta `resultados` completa (con `lecturas.csv`) dentro de
`subir_al_repositorio\challenge3\gateway\`.

## 2. Sube la carpeta challenge3 al repositorio (una sola vez)

1. Abre https://github.com/JAIMEPCI/IoT_Challenge26-1
2. Botón **Add file → Upload files**.
3. Arrastra la carpeta **challenge3** completa (la que está dentro de `subir_al_repositorio`).
4. Abajo escribe "Código e imágenes del Challenge 3" y presiona **Commit changes**.

Si GitHub no te deja subir archivos, Jaime debe agregarte como colaborador
(Settings → Collaborators) o subir él la carpeta.

**No subas** `config.h`, `config.env`, `agua.db` ni `passwd` de tu PC: tienen claves.
Esta carpeta ya viene sin ellos.

## 3. Reemplaza las 8 páginas de la wiki

Para cada archivo de `paginas_wiki`:

1. Abre la página con el mismo nombre en la wiki → **Edit**.
2. Selecciona todo el texto del editor (Ctrl + A) y bórralo.
3. Abre el archivo `.md` con el Bloc de notas, copia todo (Ctrl + A, Ctrl + C) y pégalo en el editor.
4. **Save page**.

Cada archivo trae arriba lo nuevo del Challenge 3 y debajo **todo el contenido anterior, con sus fotos**, sin cambios.

## 4. Completa lo pendiente

Busca la palabra **PENDIENTE** (Ctrl + F) en la wiki y reemplázala:

- **Página 1:** enlace del video.
- **Página 4:** la fila del nodo ESP32, con la prueba de Jaime (o déjala como pendiente).
- **Página 8:** enlace de la conversación con Claude (botón Compartir de la conversación).

## 5. Seguridad (importante)

El `README.md` de la raíz del repositorio tiene escritas la clave del WiFi de Jaime y las
credenciales del tablero del Challenge 2. Jaime debe borrarlas del README y cambiarlas,
porque el repositorio es público.

## 6. Comparte

Revisa que **@afbeltranp** tenga acceso al repositorio y que el enlace sea público.
